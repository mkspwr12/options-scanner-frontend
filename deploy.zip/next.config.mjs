/** @type {import('next').NextConfig} */
const nextConfig = {
  // Removed standalone - use standard deployment
}

export default nextConfig
